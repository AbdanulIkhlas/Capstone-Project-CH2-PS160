package com.faiz.patanistaticui.data.model

data class DataLogin (
    var email: String,
    var password: String
)