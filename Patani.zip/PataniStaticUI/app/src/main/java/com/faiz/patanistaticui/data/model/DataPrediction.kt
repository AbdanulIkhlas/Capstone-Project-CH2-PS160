package com.faiz.patanistaticui.data.model

data class DataPrediction (
    var startDate: String,
    var endDate: String? = null,
    var komoditi: String? = null,
)