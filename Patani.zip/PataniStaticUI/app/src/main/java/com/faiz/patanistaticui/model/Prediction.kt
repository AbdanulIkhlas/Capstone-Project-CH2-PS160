package com.faiz.patanistaticui.model

data class Prediction(
    val namaProduk: String,
    val prediksiHarga: Int
)